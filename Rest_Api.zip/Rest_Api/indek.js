const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const kelasRoutes = require("./routes/kelas");
const matakuliahRoutes = require("./routes/matakuliah");

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use("/api/kelas", kelasRoutes); // Endpoint untuk data kelas
app.use("/api/matakuliah", matakuliahRoutes); // Endpoint untuk data matakuliah

// Root endpoint
app.get("/", (req, res) => {
  res.send("Welcome to the Jadwal API!");
});

// Error handling
app.use((req, res) => {
  res.status(404).json({ message: "Endpoint not found" });
});

// Start server
const PORT = 3005;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
