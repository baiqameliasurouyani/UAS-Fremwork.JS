const express = require("express");
const router = express.Router();
const db = require("../config/db"); // Sesuaikan dengan konfigurasi database Anda

// GET semua matakuliah
router.get("/", (req, res) => {
  db.query("SELECT * FROM matakuliah", (err, results) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: "Error retrieving matakuliah data" });
    } else {
      res.json(results);
    }
  });
});

// POST tambah matakuliah
router.post("/", (req, res) => {
  const { matakuliah } = req.body;
  db.query("INSERT INTO matakuliah (matakuliah) VALUES (?)", [matakuliah], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: "Error adding matakuliah" });
    } else {
      res.status(201).json({ message: "Matakuliah added", id: result.insertId });
    }
  });
});

// PUT update matakuliah
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { matakuliah } = req.body;
  db.query("UPDATE matakuliah SET matakuliah = ? WHERE id_mk = ?", [matakuliah, id], (err) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: "Error updating matakuliah" });
    } else {
      res.json({ message: "Matakuliah updated" });
    }
  });
});

// DELETE matakuliah
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM matakuliah WHERE id_mk = ?", [id], (err) => {
    if (err) {
      console.error(err);
      res.status(500).json({ message: "Error deleting matakuliah" });
    } else {
      res.json({ message: "Matakuliah deleted" });
    }
  });
});

module.exports = router;
