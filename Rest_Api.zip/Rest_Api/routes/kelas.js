const express = require("express");
const router = express.Router();
const db = require("../config/db");

// GET semua kelas
router.get("/", (req, res) => {
  db.query("SELECT * FROM kelas", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// POST tambah kelas
router.post("/", (req, res) => {
  const { kelas, jam, id_mk } = req.body;
  db.query("INSERT INTO kelas (kelas, jam, id_mk) VALUES (?, ?, ?)", [kelas, jam, id_mk], (err) => {
    if (err) throw err;
    res.json({ message: "Kelas added!" });
  });
});

// PUT update kelas
router.put("/:id", (req, res) => {
    const { id } = req.params;
    const { kelas, jam, id_mk } = req.body;
    db.query(
      "UPDATE kelas SET kelas = ?, jam = ?, id_mk = ? WHERE id = ?",
      [kelas, jam, id_mk, id],
      (err) => {
        if (err) throw err;
        res.json({ message: "Kelas updated!" });
      }
    );
  });
  
  // DELETE hapus kelas
  router.delete("/:id", (req, res) => {
    const { id } = req.params;
    db.query("DELETE FROM kelas WHERE id = ?", [id], (err) => {
      if (err) throw err;
      res.json({ message: "Kelas deleted!" });
    });
  });
  
  module.exports = router;
  